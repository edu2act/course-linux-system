#!/bin/bash

while date ; do
    sleep 1
    clear
done

