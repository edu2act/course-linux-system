#!/bin/bash


if ! test -d ~/sh ; then
    mkdir ~/sh
elif test -d ~/sh/study ; then
    echo 'ok'
else
    echo 'create study'
    mkdir sh/study
fi

